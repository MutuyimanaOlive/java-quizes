// program to show inheritance of a mother and a child

class mother{  
void  mothername(){System.out.println("anna's doughter is betty");}  
}  
class child extends mother{  
void childname(){System.out.println("betty is a doughter of anna");}  
}  
class parent{  
public static void main(String args[]){  
child d=new child();  
d.mothername();  
d.childname();  
 
}}  
 //overloadingmultiplication program in java


class multiplication{  
  void multiplying(int a,int b){System.out.println("3*7 equals: "+(a*b));}  
  void multiplying(int a,int b,int c){System.out.println("3*7*2 equals: "+(a*b*c));}  
  
  public static void main(String args[]){  
  multiply obj=new multiply();  
  obj.multiplying(10,10);
  obj.multiplying(10,10,2);  
  
  }  
}  
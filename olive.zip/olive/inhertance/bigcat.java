// program to print fruit types

class cats{  
void  family(){System.out.println("cats family");}  
}  
class lions extends cats{  
void type1(){System.out.println("lions are among the cats family");}  
}  
class bigcat{  
public static void main(String args[]){  
lions d=new lions();  
d.family();  
d.type1();  
 
}}  